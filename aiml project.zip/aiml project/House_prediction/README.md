# 🏡 House Price Prediction System — AIML Mini Project

A fully functional, beginner-friendly Machine Learning web application developed for the Master of Computer Applications (MCA) Artificial Intelligence and Machine Learning (AIML) laboratory curriculum.

This project predicts residential house prices in Indian metropolitan localities using **Multiple Linear Regression (OLS)**, **Scikit-Learn Pipelines**, **ColumnTransformer**, and an interactive **Streamlit** dark-mode dashboard.

---

## 📑 Table of Contents

1. [Project Overview](#1-project-overview)
2. [Objectives](#2-objectives)
3. [Key Features](#3-key-features)
4. [Technology Stack](#4-technology-stack)
5. [Project Folder Structure](#5-project-folder-structure)
6. [Dataset Explanation](#6-dataset-explanation)
7. [Machine Learning Pipeline & Implementation](#7-machine-learning-pipeline--implementation)
8. [Model Evaluation & Results](#8-model-evaluation--results)
9. [Step-by-Step Execution Guide (Windows CMD)](#9-step-by-step-execution-guide-windows-cmd)
10. [Walkthrough of Example Predictions](#10-walkthrough-of-example-predictions)
11. [College Viva & Interview Questions (Top 10 Q&A)](#11-college-viva--interview-questions-top-10-qa)
12. [Future Improvements](#12-future-improvements)

---

## 1. Project Overview

Real estate valuation depends on a multitude of spatial, infrastructural, and physical characteristics. Manual property estimation often suffers from human bias, lack of standardization, and delayed assessments.

The **House Price Prediction System** provides a transparent, algorithmic valuation tool where users can enter house characteristics (area in square feet, bedrooms, bathrooms, property age, location, and parking) and instantly receive an estimated property valuation in **Indian Rupees (₹)** formatted in standard Indian Lakhs and Crores.

---

## 2. Objectives

- **Develop a Supervised ML Model:** Implement Multiple Linear Regression using Scikit-Learn to estimate house prices.
- **Enforce Best ML Practices:** Utilize `Pipeline` and `ColumnTransformer` to guarantee zero data leakage between training and testing data splits.
- **Create an Intuitive Frontend:** Develop a multi-page interactive web interface using Streamlit with responsive inputs and dark-theme aesthetics.
- **Provide Actionable Insights:** Include exploratory data visualizations (scatter plots, distributions, bar charts) and transparent coefficient explanations suitable for an MCA college viva.

---

## 3. Key Features

- **Multi-Page Dashboard:**
  - `🏠 Home`: Project introduction, objectives, features, and system workflow.
  - `🔮 Predict House Price`: Interactive form with sliders, dropdowns, validation checks, and price hero card with estimated market ranges.
  - `📊 Data Analysis`: Matplotlib EDA charts (Area vs Price trendline, Location average prices, and Price distribution histogram).
  - `📈 Model Performance`: Evaluated on a strictly held-out 20% test set ($R^2$, MAE, RMSE), Actual vs Predicted plot, and coefficient breakdown.
  - `ℹ️ About Project`: Architecture overview, dataset limitations, and viva Q&A guide.
- **Authentic Indian Currency Formatting:** Automatic conversion to standard Indian grouping (e.g., `₹ 1,25,00,000 (₹ 1.25 Crore)`).
- **Zero Retraining Overhead:** Model is trained once and saved using `joblib`. Predictions are served in sub-milliseconds with `@st.cache_resource`.
- **Robust Input Validation:** Rejects impossible inputs (e.g., 5 bedrooms in 300 sq.ft or negative values).

---

## 4. Technology Stack

| Layer | Technology | Version | Purpose |
| :--- | :--- | :--- | :--- |
| **Language** | Python | 3.12 / 3.13 | Core programming language |
| **ML Algorithm** | Linear Regression | Scikit-Learn (1.9+) | Supervised Ordinary Least Squares (OLS) regression |
| **Preprocessing** | Pipeline & ColumnTransformer | Scikit-Learn | One-hot encoding & data leakage prevention |
| **Data Manipulation** | Pandas & NumPy | 3.0+ / 2.4+ | Dataset handling, array operations, and math |
| **Visualizations** | Matplotlib | 3.11+ | High-resolution dark-themed charts |
| **Web Frontend** | Streamlit | 1.40+ / 1.66+ | Multi-page responsive web dashboard |
| **Model Persistence**| Joblib | 1.6+ | Serializing & loading trained ML pipeline |

---

## 5. Project Folder Structure

```text
House_prediction/
│
├── app.py                      # Main Streamlit multi-page web application
├── train_model.py              # ML training script (Pipeline + Evaluation)
├── generate_dataset.py         # Realistic Indian housing dataset generator
├── test_system.py              # Automated unit tests for all modules
├── requirements.txt            # Minimal required Python dependencies
├── README.md                   # Complete documentation & College Viva Guide
│
├── data/
│   └── house_prices.csv        # 1,500 records Indian housing dataset
│
├── models/
│   ├── house_price_model.pkl   # Serialized trained scikit-learn Pipeline
│   └── metrics.json            # Model evaluation metrics & coefficients
│
├── utils/
│   ├── __init__.py             # Package marker
│   └── helpers.py              # Currency formatters, validators & model loader
│
├── assets/
│   └── style.css               # Modern dark theme styles (Indigo/Purple/Blue)
│
└── .streamlit/
    ├── config.toml             # Streamlit dark theme configuration
    └── credentials.toml        # Streamlit headless credentials
```

---

## 6. Dataset Explanation

The dataset (`data/house_prices.csv`) contains **1,500 property records** representing Indian metropolitan real estate markets across major tech hubs and cultural capitals.

### Dataset Features:

| Column Name | Data Type | Description | Example Values |
| :--- | :--- | :--- | :--- |
| `area_sqft` | Integer | Super built-up area in square feet | 600 to 4,200 |
| `bedrooms` | Integer | Number of bedrooms (BHK) | 1, 2, 3, 4, 5 |
| `bathrooms` | Integer | Number of bathrooms | 1 to 5 |
| `property_age` | Integer | Age of property in years | 0 (New) to 25 |
| `location` | String | Locality and city | Whitefield (Bengaluru), Andheri West (Mumbai), etc. |
| `parking` | String | Reserved vehicle parking | "Yes", "No" |
| `price` | Integer | Target property price in Indian Rupees | ₹ 28,00,000 to ₹ 6,64,00,000 |

### Included Localities:
1. Whitefield, Bengaluru
2. Indiranagar, Bengaluru
3. Andheri West, Mumbai
4. Bandra West, Mumbai
5. Gachibowli, Hyderabad
6. Banjara Hills, Hyderabad
7. Kothrud, Pune
8. Wakad, Pune
9. Connaught Place, New Delhi
10. Salt Lake, Kolkata

---

## 7. Machine Learning Pipeline & Implementation

The project implements a **Multiple Linear Regression** algorithm using Scikit-Learn.

### Mathematical Formulation:

$$\hat{y} = \beta_0 + \beta_1 X_{\text{area}} + \beta_2 X_{\text{bedrooms}} + \beta_3 X_{\text{bathrooms}} + \beta_4 X_{\text{age}} + \sum_{k} \beta_{k} D_{\text{location}_k} + \beta_p D_{\text{parking}} + \epsilon$$

Where:
- $\beta_0$: Intercept (baseline price).
- $\beta_i$: Learned weights representing marginal rupee change per unit.
- $D_k$: Dummy indicator variable (0 or 1) generated by `OneHotEncoder`.

### Preprocessing & Leakage Prevention:
To ensure rigorous ML compliance:
1. Data is split **80% training (1,200 samples)** and **20% testing (300 samples)** with a fixed `random_state=42`.
2. A `ColumnTransformer` is fitted **solely on `X_train`**:
   - `['location', 'parking']`: Encoded using `OneHotEncoder(drop='first', handle_unknown='ignore')`.
   - `['area_sqft', 'bedrooms', 'bathrooms', 'property_age']`: Numeric features passed directly to preserve direct rupee coefficient interpretability.
3. The trained pipeline is serialized into `models/house_price_model.pkl`.

---

## 8. Model Evaluation & Results

The model was tested against 300 unseen properties from the held-out test split:

| Evaluation Metric | Measured Value | Meaning |
| :--- | :--- | :--- |
| **$R^2$ Score (Test Accuracy)** | **0.9092 (90.92%)** | Over 90% of price variation is accurately explained by the features |
| **$R^2$ Score (Train Set)** | **0.9223 (92.23%)** | Close train & test scores prove no overfitting or underfitting |
| **Mean Absolute Error (MAE)** | **₹ 19,36,742.97** | Average magnitude of difference between predicted and actual price |
| **Root Mean Squared Error (RMSE)**| **₹ 28,25,730.30** | Penalizes larger error deviations appropriately |

---

## 9. Step-by-Step Execution Guide (Windows CMD)

Open **Windows Command Prompt (CMD)** or **PowerShell**, navigate to the project directory, and execute the following commands:

### Step 1: Verify Python & Pip Installation
```cmd
python --version
pip --version
```
*(Ensure Python 3.10+ is installed)*

### Step 2: Install Project Dependencies
```cmd
pip install -r requirements.txt
```

### Step 3: Generate the Dataset (Optional if CSV already exists)
```cmd
python generate_dataset.py
```

### Step 4: Train the Linear Regression Model
```cmd
python train_model.py
```
*This validates the data, trains the Pipeline, computes evaluation metrics, and saves `models/house_price_model.pkl`.*

### Step 5: Run Automated Unit Tests (Optional Verification)
```cmd
python test_system.py
```
*(All 5 test cases will pass with OK)*

### Step 6: Launch the Streamlit Web Application
```cmd
python -m streamlit run app.py
```

Your default web browser will automatically open:
```text
Local URL: http://localhost:8501
```

---

## 10. Walkthrough of Example Predictions

### Example Scenario 1: 3 BHK in Whitefield, Bengaluru
- **Area:** 1,500 sq.ft
- **Bedrooms:** 3 BHK
- **Bathrooms:** 2
- **Property Age:** 4 Years
- **Location:** Whitefield, Bengaluru
- **Parking:** Yes
- **Estimated Price:** **₹ 1,24,16,000 (₹ 1.24 Crore)**
- **Fair Market Range:** ₹ 1.19 Cr to ₹ 1.29 Cr

### Example Scenario 2: 2 BHK in Andheri West, Mumbai
- **Area:** 950 sq.ft
- **Bedrooms:** 2 BHK
- **Bathrooms:** 2
- **Property Age:** 2 Years
- **Location:** Andheri West, Mumbai
- **Parking:** Yes
- **Estimated Price:** **₹ 1,36,80,000 (₹ 1.37 Crore)**
- **Fair Market Range:** ₹ 1.31 Cr to ₹ 1.42 Cr

---

## 11. College Viva & Interview Questions (Top 10 Q&A)

### Q1: What is Multiple Linear Regression and why did you choose it for this mini project?
> **Answer:** Multiple Linear Regression is a supervised learning algorithm that models the linear relationship between two or more independent features and a continuous target variable. It was chosen because residential property valuation fundamentally exhibits a strong linear correlation with physical dimensions (area, bedrooms), and its learned coefficients offer 100% mathematical transparency.

### Q2: What is the purpose of using a Scikit-Learn `Pipeline`?
> **Answer:** A `Pipeline` chains together data preprocessing steps (`ColumnTransformer`) and the estimator (`LinearRegression`) into a single atomic object. This ensures that any preprocessing fitted on training data is automatically and consistently applied to test and user inference data without manual recoding.

### Q3: How do you prevent Data Leakage in your machine learning project?
> **Answer:** Data leakage happens when information from outside the training set contaminates the model. We prevented this by performing an 80/20 `train_test_split` **before** fitting the preprocessing transformers. Transformers and models are fitted strictly on `X_train` only.

### Q4: How is categorical data like 'location' handled by the model?
> **Answer:** Categorical strings cannot be mathematically computed directly. We used `OneHotEncoder(drop='first')`, which creates binary dummy indicator columns (0 or 1). Dropping the first category prevents multicollinearity, commonly known as the **dummy variable trap**.

### Q5: What does the R² score (Coefficient of Determination) measure?
> **Answer:** $R^2$ measures the proportion of total variance in the dependent variable that is explained by the independent variables. Our model achieves an $R^2$ of **0.9092 (90.92%)** on held-out test data, meaning over 90% of price variance is successfully captured.

### Q6: What is the difference between MAE and RMSE?
> **Answer:**
> - **Mean Absolute Error (MAE):** The linear average of absolute differences $|y - \hat{y}|$. It represents typical error magnitude directly in Rupees.
> - **Root Mean Squared Error (RMSE):** The square root of averaged squared errors $\sqrt{\frac{1}{N}\sum(y - \hat{y})^2}$. Because errors are squared, RMSE penalizes large outlier errors more heavily.

### Q7: Why do you cache the model using `@st.cache_resource` in Streamlit?
> **Answer:** Streamlit reruns the entire Python script upon every user interaction (such as moving a slider). Without caching, the model would reload from disk on every keystroke. `@st.cache_resource` loads the model once into RAM and reuses it across all interactions, ensuring instantaneous predictions.

### Q8: What does the intercept ($\beta_0$) represent in your regression model?
> **Answer:** In regression, the intercept ($\beta_0$) is the expected value of $y$ when all predictor variables are set to zero (and reference categories apply). In real estate, it acts as the baseline pricing anchor for the base reference locality.

### Q9: What are the key assumptions of Linear Regression?
> **Answer:**
> 1. **Linearity:** The relationship between features and target is linear.
> 2. **Independence:** Observations are independent of each other.
> 3. **Homoscedasticity:** Constant variance of residuals across all levels of $X$.
> 4. **Normality of Errors:** Residuals ($y - \hat{y}$) follow a normal distribution centered at zero.

### Q10: How can you tell if the model is overfitting or underfitting?
> **Answer:** We compare training and testing performance. In our model, **Train $R^2 = 92.23\%$** and **Test $R^2 = 90.92\%$**. Because the training accuracy is high and the testing accuracy is very close to it, the model demonstrates good generalization without overfitting or underfitting.

---

## 12. Future Improvements

1. **Ensemble & Non-Linear Models:** Compare Linear Regression against Random Forest Regressor and XGBoost to capture subtle non-linear market interactions.
2. **Interactive Map Integration:** Integrate Folium / OpenStreetMap to allow users to pin exact locations by latitude and longitude.
3. **Neighborhood Infrastructure Scoring:** Add proximity metrics for metro stations, IT corridors, schools, and hospitals.
4. **FastAPI Microservice:** Package the prediction pipeline into a Dockerized REST API for mobile app consumption.

---

**Developed for MCA AIML Mini Project Laboratory Demonstration.**

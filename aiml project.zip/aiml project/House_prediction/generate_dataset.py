"""
generate_dataset.py
-------------------
Generates a realistic synthetic Indian housing dataset for the House Price Prediction System.
Columns: area_sqft, bedrooms, bathrooms, property_age, location, parking, price

This script uses a fixed random seed (42) for reproducibility and creates 1,500 records.
Pricing is logically modeled based on metropolitan Indian real estate dynamics.
"""

import os
import numpy as np
import pandas as pd

def generate_housing_dataset(n_samples=1500, random_seed=42):
    """
    Generate realistic synthetic Indian housing dataset.
    
    Parameters:
        n_samples (int): Total number of housing records to generate (default 1500).
        random_seed (int): Seed for reproducibility.
        
    Returns:
        pd.DataFrame: Generated dataset containing property features and price in INR.
    """
    np.random.seed(random_seed)
    
    # Location base rates in INR per sq.ft. reflecting popular Indian localities
    location_profiles = {
        "Whitefield, Bengaluru": {"base_rate": 7500, "weight": 0.12},
        "Indiranagar, Bengaluru": {"base_rate": 11000, "weight": 0.10},
        "Andheri West, Mumbai": {"base_rate": 13500, "weight": 0.11},
        "Bandra West, Mumbai": {"base_rate": 16000, "weight": 0.08},
        "Gachibowli, Hyderabad": {"base_rate": 7200, "weight": 0.11},
        "Banjara Hills, Hyderabad": {"base_rate": 10500, "weight": 0.09},
        "Kothrud, Pune": {"base_rate": 6800, "weight": 0.10},
        "Wakad, Pune": {"base_rate": 5800, "weight": 0.11},
        "Connaught Place, New Delhi": {"base_rate": 14500, "weight": 0.08},
        "Salt Lake, Kolkata": {"base_rate": 6200, "weight": 0.10}
    }
    
    locations = list(location_profiles.keys())
    weights = [location_profiles[loc]["weight"] for loc in locations]
    
    chosen_locations = np.random.choice(locations, size=n_samples, p=weights)
    
    records = []
    
    for i in range(n_samples):
        loc = chosen_locations[i]
        base_rate = location_profiles[loc]["base_rate"]
        
        # Area in sqft between 550 and 4200 sqft
        # Logically conditioned distribution: 1BHK, 2BHK, 3BHK, 4BHK, 5BHK
        bhk_type = np.random.choice([1, 2, 3, 4, 5], p=[0.12, 0.38, 0.32, 0.14, 0.04])
        
        if bhk_type == 1:
            area = int(np.random.uniform(550, 850))
            bathrooms = 1
        elif bhk_type == 2:
            area = int(np.random.uniform(850, 1350))
            bathrooms = np.random.choice([1, 2], p=[0.25, 0.75])
        elif bhk_type == 3:
            area = int(np.random.uniform(1350, 2100))
            bathrooms = np.random.choice([2, 3], p=[0.30, 0.70])
        elif bhk_type == 4:
            area = int(np.random.uniform(2100, 3100))
            bathrooms = np.random.choice([3, 4], p=[0.35, 0.65])
        else: # 5 BHK
            area = int(np.random.uniform(3100, 4200))
            bathrooms = np.random.choice([4, 5], p=[0.40, 0.60])
            
        bedrooms = bhk_type
        
        # Property age between 0 (new construction) and 25 years
        property_age = int(np.random.choice(np.arange(0, 26), p=np.linspace(1.5, 0.5, 26)/np.sum(np.linspace(1.5, 0.5, 26))))
        
        # Parking availability (75% Yes, 25% No)
        parking = np.random.choice(["Yes", "No"], p=[0.75, 0.25])
        parking_val = 350000 if parking == "Yes" else 0
        
        # Logical price calculation formula:
        # Base price = Area * Location Rate
        # + Bedroom premium (₹ 2,00,000 per bedroom)
        # + Bathroom premium (₹ 1,50,000 per bathroom)
        # + Parking bonus (₹ 3,50,000)
        # - Age depreciation (₹ 45,000 per year)
        # + Realistic market noise (Normal distribution ~ 3.5% std dev)
        
        base_cost = area * base_rate
        bedroom_premium = bedrooms * 200000
        bathroom_premium = bathrooms * 150000
        age_depreciation = property_age * 45000
        
        subtotal = base_cost + bedroom_premium + bathroom_premium + parking_val - age_depreciation
        
        # Add realistic minor market variance (approx +-3.5%)
        noise = np.random.normal(0, subtotal * 0.035)
        raw_price = subtotal + noise
        
        # Ensure minimum logical price threshold and round to nearest thousand
        final_price = max(1800000, round(raw_price / 1000) * 1000)
        
        records.append({
            "area_sqft": area,
            "bedrooms": bedrooms,
            "bathrooms": bathrooms,
            "property_age": property_age,
            "location": loc,
            "parking": parking,
            "price": int(final_price)
        })
        
    df = pd.DataFrame(records)
    return df

def main():
    print("=" * 60)
    print("      INDIAN HOUSING DATASET GENERATOR (AIML PROJECT)")
    print("=" * 60)
    
    # Target directory setup
    output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "house_prices.csv")
    
    # Generate 1500 records
    df = generate_housing_dataset(n_samples=1500, random_seed=42)
    
    # Save dataset to CSV
    df.to_csv(output_path, index=False)
    print(f"[+] Dataset successfully generated and saved to: {output_path}")
    print(f"[+] Total records: {len(df)}")
    print(f"[+] Features: {list(df.columns)}")
    print("\n[+] Dataset First 5 Rows:")
    print(df.head())
    print("\n[+] Data Types:")
    print(df.dtypes)
    print("\n[+] Missing Values Check:")
    print(df.isnull().sum())
    print("\n[+] Summary Statistics:")
    print(df.describe())
    print("=" * 60)

if __name__ == "__main__":
    main()

"""
app.py
------
House Price Prediction System - Streamlit Web Application
AIML College Mini Project (MCA)

Algorithms: Multiple Linear Regression with scikit-learn Pipeline
Frontend: Streamlit (Multi-page dashboard with custom Dark UI)
"""

import os
import sys
import tempfile

# Ensure Matplotlib config directory is writable to eliminate cache warnings
os.environ.setdefault("MPLCONFIGDIR", os.path.join(tempfile.gettempdir(), "matplotlib_cache"))

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

# Safe UTF-8 console output for Windows
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Import helper functions
from utils.helpers import (
    load_trained_model,
    load_dataset,
    load_metrics,
    predict_price,
    format_inr,
    format_inr_short,
    validate_inputs,
    DATA_PATH,
    MODEL_PATH,
    METRICS_PATH
)

# ---------------------------------------------------------
# Streamlit Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="House Price Prediction System | AIML Project",
    page_icon="🏡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------------------------------------------------
# Load Custom Dark Theme CSS
# ---------------------------------------------------------
def load_css():
    css_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "style.css")
    if os.path.exists(css_path):
        with open(css_path, "r", encoding="utf-8") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css()

# ---------------------------------------------------------
# Cached Resource Loaders (Fast, prevents model retraining)
# ---------------------------------------------------------
@st.cache_resource(show_spinner=False)
def get_model():
    """Load and cache the trained ML pipeline."""
    try:
        return load_trained_model(MODEL_PATH)
    except FileNotFoundError:
        return None

@st.cache_data(show_spinner=False)
def get_data():
    """Load and cache the housing dataset."""
    try:
        return load_dataset(DATA_PATH)
    except FileNotFoundError:
        return None

@st.cache_data(show_spinner=False)
def get_metrics():
    """Load and cache saved evaluation metrics."""
    return load_metrics(METRICS_PATH)

# Initialize cached objects
model = get_model()
df = get_data()
metrics = get_metrics()

# ---------------------------------------------------------
# Sidebar Navigation & Project Metadata
# ---------------------------------------------------------
st.sidebar.markdown(
    """
    <div style="text-align: center; padding: 10px 0 16px 0;">
        <span style="font-size: 2.5rem;">🏡</span>
        <h2 style="margin: 4px 0 0 0; color: #f8fafc; font-size: 1.35rem; font-weight: 700;">
            House Predictor
        </h2>
        <span class="badge badge-purple" style="margin-top: 6px;">AIML Mini Project</span>
    </div>
    """,
    unsafe_allow_html=True
)

st.sidebar.markdown("---")

menu_choice = st.sidebar.radio(
    "Navigation Menu",
    [
        "🏠 Home",
        "🔮 Predict House Price",
        "📊 Data Analysis",
        "📈 Model Performance",
        "ℹ️ About Project"
    ],
    index=0
)

st.sidebar.markdown("---")

# Model Status Widget in Sidebar
if model is not None:
    st.sidebar.markdown(
        """
        <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 10px; padding: 12px; margin-bottom: 12px;">
            <div style="color: #6ee7b7; font-size: 0.82rem; font-weight: 700; text-transform: uppercase;">● Model Status: Ready</div>
            <div style="color: #cbd5e1; font-size: 0.85rem; margin-top: 4px;">Algorithm: <b>Linear Regression</b></div>
            <div style="color: #cbd5e1; font-size: 0.85rem;">Pipeline: <b>Scikit-Learn</b></div>
        </div>
        """,
        unsafe_allow_html=True
    )
else:
    st.sidebar.warning("⚠️ Model not loaded. Run train_model.py to initialize.")

st.sidebar.markdown(
    """
    <div style="font-size: 0.80rem; color: #64748b; line-height: 1.4; padding: 4px 8px;">
        MCA Department Mini Project<br>
        Currency: <b>Indian Rupees (₹)</b><br>
        Environment: Windows 11
    </div>
    """,
    unsafe_allow_html=True
)


# =========================================================
# PAGE 1: HOME
# =========================================================
if menu_choice == "🏠 Home":
    st.markdown(
        """
        <div class="hero-card">
            <span class="badge badge-purple">College AIML Project</span>
            <h1 class="hero-title">House Price Prediction System</h1>
            <p class="hero-subtitle">
                An end-to-end Machine Learning web application designed to predict residential property prices in Indian metropolitan cities using Multiple Linear Regression, Scikit-Learn Pipelines, and Streamlit.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Project Objectives
    st.markdown("### 🎯 Project Objectives")
    col_obj1, col_obj2, col_obj3 = st.columns(3)

    with col_obj1:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-icon">🧠</div>
                <div class="card-title">Accurate ML Estimation</div>
                <div class="card-desc">
                    Leverage Multiple Linear Regression trained on property dimensions, location premiums, age depreciation, and parking facilities.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_obj2:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-icon">🛡️</div>
                <div class="card-title">Data Leakage Prevention</div>
                <div class="card-desc">
                    Implement scikit-learn <code>Pipeline</code> and <code>ColumnTransformer</code> to ensure strict separation between training and test distributions.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col_obj3:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-icon">🇮🇳</div>
                <div class="card-title">Indian Rupee Valuation</div>
                <div class="card-desc">
                    Display valuations in authentic Indian currency formatting (₹ Lakhs & Crores) tailored for prominent metropolitan localities.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Core Features
    st.markdown("### ✨ Key Features of the System")
    feat_col1, feat_col2 = st.columns(2)

    with feat_col1:
        st.markdown(
            """
            - 🔹 **Interactive Input Controls**: Sliders and dropdowns for area, bedrooms, bathrooms, age, and parking.
            - 🔹 **Instant Inference**: Model is preloaded and cached using `@st.cache_resource` for sub-millisecond predictions.
            - 🔹 **Strict Input Validation**: Rejects logically impossible house configurations (e.g., 5 bedrooms in 400 sq.ft).
            - 🔹 **Price Range Bounds**: Provides estimated market fluctuation bounds (±4%) alongside the central estimate.
            """
        )

    with feat_col2:
        st.markdown(
            """
            - 🔹 **Visual Exploratory Analysis**: Matplotlib scatter plots, price distributions, and location price comparisons.
            - 🔹 **Model Performance Metrics**: Real evaluation metrics ($R^2$, MAE, RMSE) computed strictly on held-out test data.
            - 🔹 **Coefficients Breakdown**: Full transparent insight into how each feature affects the base property price.
            - 🔹 **Viva Ready Architecture**: Clean, modular structure without unnecessary complex frameworks or paid APIs.
            """
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Workflow Section
    st.markdown("### 🔄 How the Prediction System Works")
    st.markdown(
        """
        <div style="background: rgba(30, 41, 59, 0.5); border-radius: 12px; border: 1px solid rgba(148, 163, 184, 0.2); padding: 22px;">
            <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 15px;">
                <div style="flex: 1; min-width: 180px; background: rgba(15, 23, 42, 0.6); padding: 14px; border-radius: 8px; border-left: 3px solid #6366f1;">
                    <b style="color: #a5b4fc;">Step 1: Input Entry</b><br>
                    <span style="font-size: 0.88rem; color: #cbd5e1;">User provides area, BHK, baths, age, location, and parking.</span>
                </div>
                <div style="flex: 1; min-width: 180px; background: rgba(15, 23, 42, 0.6); padding: 14px; border-radius: 8px; border-left: 3px solid #8b5cf6;">
                    <b style="color: #c084fc;">Step 2: Preprocessing</b><br>
                    <span style="font-size: 0.88rem; color: #cbd5e1;">ColumnTransformer one-hot encodes location & parking features.</span>
                </div>
                <div style="flex: 1; min-width: 180px; background: rgba(15, 23, 42, 0.6); padding: 14px; border-radius: 8px; border-left: 3px solid #3b82f6;">
                    <b style="color: #93c5fd;">Step 3: ML Inference</b><br>
                    <span style="font-size: 0.88rem; color: #cbd5e1;">Linear Regression calculates: <code>y = β₀ + β₁X₁ + ... + βₙXₙ</code>.</span>
                </div>
                <div style="flex: 1; min-width: 180px; background: rgba(15, 23, 42, 0.6); padding: 14px; border-radius: 8px; border-left: 3px solid #10b981;">
                    <b style="color: #6ee7b7;">Step 4: Result Display</b><br>
                    <span style="font-size: 0.88rem; color: #cbd5e1;">Price presented in ₹ Lakhs / Crores with Indian comma grouping.</span>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )


# =========================================================
# PAGE 2: PREDICT HOUSE PRICE
# =========================================================
elif menu_choice == "🔮 Predict House Price":
    st.markdown(
        """
        <div class="hero-card" style="padding: 20px 24px;">
            <h2 style="color: #f1f5f9; margin: 0 0 4px 0; font-size: 1.8rem; font-weight: 700;">
                Property Price Estimator
            </h2>
            <p style="color: #94a3b8; margin: 0; font-size: 0.95rem;">
                Enter property specifications below to receive an estimated valuation in Indian Rupees (₹).
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    if model is None:
        st.error(
            "⚠️ Trained model not found! Please run the training script from your terminal: "
            "`python train_model.py`"
        )
        st.stop()

    # Pre-populate location options from dataset or saved metrics
    available_locations = metrics.get("locations", [
        "Andheri West, Mumbai",
        "Bandra West, Mumbai",
        "Banjara Hills, Hyderabad",
        "Connaught Place, New Delhi",
        "Gachibowli, Hyderabad",
        "Indiranagar, Bengaluru",
        "Kothrud, Pune",
        "Salt Lake, Kolkata",
        "Wakad, Pune",
        "Whitefield, Bengaluru"
    ])

    # Form Layout
    with st.form("prediction_form"):
        st.markdown("#### 📋 Property Details")
        col1, col2 = st.columns(2)

        with col1:
            area_sqft = st.number_input(
                "Super Built-up Area (Square Feet)",
                min_value=300,
                max_value=10000,
                value=1450,
                step=50,
                help="Total carpet + common super built-up area in sq.ft."
            )

            bedrooms = st.slider(
                "Number of Bedrooms (BHK)",
                min_value=1,
                max_value=6,
                value=3,
                step=1,
                help="Total number of bedrooms in the property."
            )

            bathrooms = st.slider(
                "Number of Bathrooms",
                min_value=1,
                max_value=6,
                value=2,
                step=1,
                help="Total number of attached and common bathrooms."
            )

        with col2:
            location = st.selectbox(
                "Property Location / City",
                options=available_locations,
                index=available_locations.index("Whitefield, Bengaluru") if "Whitefield, Bengaluru" in available_locations else 0,
                help="Select the prime locality and city."
            )

            property_age = st.slider(
                "Property Age (in Years)",
                min_value=0,
                max_value=30,
                value=4,
                step=1,
                help="0 means newly constructed / ready-to-move brand new."
            )

            parking = st.radio(
                "Dedicated Reserved Parking",
                options=["Yes", "No"],
                index=0,
                horizontal=True,
                help="Does the flat/house include reserved car parking?"
            )

        st.markdown("<br>", unsafe_allow_html=True)
        predict_btn = st.form_submit_button("🔍 Predict Estimated Price", use_container_width=True)

    # Prediction Action
    if predict_btn:
        # 1. Validation
        is_valid, err_msg = validate_inputs(
            area_sqft=area_sqft,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            property_age=property_age,
            location=location,
            parking=parking,
            allowed_locations=available_locations
        )

        if not is_valid:
            st.error(f"❌ Input Validation Error: {err_msg}")
        else:
            with st.spinner("🤖 Running Linear Regression Pipeline inference..."):
                input_payload = {
                    "area_sqft": area_sqft,
                    "bedrooms": bedrooms,
                    "bathrooms": bathrooms,
                    "property_age": property_age,
                    "location": location,
                    "parking": parking
                }
                result = predict_price(model, input_payload)

            # Display Highlighted Result Card
            st.markdown(
                f"""
                <div class="prediction-box">
                    <div class="prediction-label">Estimated Market Valuation</div>
                    <div class="prediction-amount">{format_inr(result['raw_price'], include_words=False)}</div>
                    <div class="prediction-words">{result['formatted_short']} ({result['formatted_full'].split('(')[-1].replace(')', '')})</div>
                    <div class="prediction-range">
                        Expected Fair Market Range: <b>{result['lower_bound_formatted']}</b> to <b>{result['upper_bound_formatted']}</b>
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

            # Property Input Summary
            st.markdown("#### 📑 Summary of Entered Property Specifications")
            sum_c1, sum_c2, sum_c3, sum_c4, sum_c5, sum_c6 = st.columns(6)

            with sum_c1:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Area</div>
                        <div class="metric-value" style="font-size: 1.25rem;">{area_sqft:,} <span style="font-size: 0.8rem;">sq.ft</span></div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with sum_c2:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Bedrooms</div>
                        <div class="metric-value" style="font-size: 1.25rem;">{bedrooms} BHK</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with sum_c3:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Bathrooms</div>
                        <div class="metric-value" style="font-size: 1.25rem;">{bathrooms}</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with sum_c4:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Age</div>
                        <div class="metric-value" style="font-size: 1.25rem;">{property_age} yrs</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with sum_c5:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Parking</div>
                        <div class="metric-value" style="font-size: 1.25rem;">{parking}</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            with sum_c6:
                st.markdown(
                    f"""
                    <div class="metric-container">
                        <div class="metric-label">Rate / sq.ft</div>
                        <div class="metric-value" style="font-size: 1.25rem;">₹ {int(result['raw_price'] / area_sqft):,}</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )


# =========================================================
# PAGE 3: DATA ANALYSIS
# =========================================================
elif menu_choice == "📊 Data Analysis":
    st.markdown(
        """
        <div class="hero-card" style="padding: 20px 24px;">
            <h2 style="color: #f1f5f9; margin: 0 0 4px 0; font-size: 1.8rem; font-weight: 700;">
                Exploratory Data Analysis (EDA)
            </h2>
            <p style="color: #94a3b8; margin: 0; font-size: 0.95rem;">
                Visualizing relationships between property attributes and housing prices across Indian metropolitan areas.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    if df is None:
        st.error("⚠️ Dataset file not found! Please run `python generate_dataset.py` first.")
        st.stop()

    # KPI Top Row
    total_records = len(df)
    avg_price = df["price"].mean()
    min_price = df["price"].min()
    max_price = df["price"].max()
    avg_area = df["area_sqft"].mean()

    kpi1, kpi2, kpi3, kpi4 = st.columns(4)
    with kpi1:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Total Properties</div>
                <div class="metric-value">{total_records:,}</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with kpi2:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Average House Price</div>
                <div class="metric-value">{format_inr_short(avg_price)}</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with kpi3:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Minimum Price</div>
                <div class="metric-value">{format_inr_short(min_price)}</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with kpi4:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Maximum Price</div>
                <div class="metric-value">{format_inr_short(max_price)}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Dataset Preview & Summary Statistics Tabs
    tab_preview, tab_stats = st.tabs(["📋 Dataset Preview", "📈 Summary Statistics"])

    with tab_preview:
        st.dataframe(
            df.head(15),
            use_container_width=True,
            column_config={
                "area_sqft": st.column_config.NumberColumn("Area (sq.ft)", format="%d"),
                "bedrooms": st.column_config.NumberColumn("BHK", format="%d"),
                "bathrooms": st.column_config.NumberColumn("Baths", format="%d"),
                "property_age": st.column_config.NumberColumn("Age (Years)", format="%d"),
                "location": st.column_config.TextColumn("Location"),
                "parking": st.column_config.TextColumn("Parking"),
                "price": st.column_config.NumberColumn("Price (₹)", format="₹ %d")
            }
        )

    with tab_stats:
        st.dataframe(df.describe().T, use_container_width=True)

    st.markdown("---")
    st.markdown("### 📊 Visualizations")

    # Matplotlib styling for dark theme
    plt.rcParams.update({
        "figure.facecolor": "#0b0f19",
        "axes.facecolor": "#111827",
        "axes.edgecolor": "#334155",
        "axes.labelcolor": "#e2e8f0",
        "xtick.color": "#94a3b8",
        "ytick.color": "#94a3b8",
        "grid.color": "#1e293b",
        "grid.linestyle": "--",
        "grid.alpha": 0.6,
        "text.color": "#f8fafc"
    })

    # Chart 1 & Chart 2
    chart_c1, chart_c2 = st.columns(2)

    with chart_c1:
        st.markdown("#### 1. Area vs Price (Scatter Plot & Trendline)")
        fig1, ax1 = plt.subplots(figsize=(7, 4.5))
        
        # Plot scatter
        ax1.scatter(
            df["area_sqft"],
            df["price"] / 10000000,
            alpha=0.55,
            color="#8b5cf6",
            edgecolors="none",
            s=28,
            label="Properties"
        )
        
        # Best-fit trendline using numpy polyfit
        m, b = np.polyfit(df["area_sqft"], df["price"] / 10000000, 1)
        x_trend = np.linspace(df["area_sqft"].min(), df["area_sqft"].max(), 100)
        ax1.plot(x_trend, m * x_trend + b, color="#38bdf8", linewidth=2.2, label="Linear Trendline")
        
        ax1.set_xlabel("Super Built-up Area (sq.ft)", fontsize=10, fontweight="bold")
        ax1.set_ylabel("Price (₹ in Crores)", fontsize=10, fontweight="bold")
        ax1.grid(True)
        ax1.legend(facecolor="#1e293b", edgecolor="#334155")
        st.pyplot(fig1)
        plt.close(fig1)

    with chart_c2:
        st.markdown("#### 2. Location-wise Average House Price")
        fig2, ax2 = plt.subplots(figsize=(7, 4.5))
        
        loc_avg = df.groupby("location")["price"].mean().sort_values(ascending=True) / 10000000
        bars = ax2.barh(loc_avg.index, loc_avg.values, color="#6366f1", edgecolor="#818cf8", height=0.65)
        
        # Add value labels on bars
        for bar in bars:
            width = bar.get_width()
            ax2.text(width + 0.05, bar.get_y() + bar.get_height()/2, f"₹{width:.2f} Cr", 
                     va="center", ha="left", color="#cbd5e1", fontsize=8.5, fontweight="500")
                     
        ax2.set_xlabel("Average Price (₹ in Crores)", fontsize=10, fontweight="bold")
        ax2.set_ylabel("Location", fontsize=10, fontweight="bold")
        ax2.grid(axis="x")
        ax2.set_xlim(0, loc_avg.max() * 1.25)
        st.pyplot(fig2)
        plt.close(fig2)

    st.markdown("<br>", unsafe_allow_html=True)

    # Chart 3: Price Distribution Histogram
    st.markdown("#### 3. House Price Distribution (Histogram)")
    fig3, ax3 = plt.subplots(figsize=(10, 4))
    
    prices_in_crores = df["price"] / 10000000
    n, bins, patches = ax3.hist(
        prices_in_crores,
        bins=28,
        color="#a855f7",
        edgecolor="#1e1b4b",
        alpha=0.85
    )
    
    # Add mean and median vertical lines
    mean_val = prices_in_crores.mean()
    median_val = prices_in_crores.median()
    
    ax3.axvline(mean_val, color="#38bdf8", linestyle="--", linewidth=2, label=f"Mean: ₹{mean_val:.2f} Cr")
    ax3.axvline(median_val, color="#f59e0b", linestyle=":", linewidth=2, label=f"Median: ₹{median_val:.2f} Cr")
    
    ax3.set_xlabel("Property Price (₹ in Crores)", fontsize=10, fontweight="bold")
    ax3.set_ylabel("Number of Houses", fontsize=10, fontweight="bold")
    ax3.grid(True)
    ax3.legend(facecolor="#1e293b", edgecolor="#334155")
    st.pyplot(fig3)
    plt.close(fig3)


# =========================================================
# PAGE 4: MODEL PERFORMANCE
# =========================================================
elif menu_choice == "📈 Model Performance":
    st.markdown(
        """
        <div class="hero-card" style="padding: 20px 24px;">
            <h2 style="color: #f1f5f9; margin: 0 0 4px 0; font-size: 1.8rem; font-weight: 700;">
                Model Evaluation & Algorithm Performance
            </h2>
            <p style="color: #94a3b8; margin: 0; font-size: 0.95rem;">
                Quantitative metrics calculated on the <b>held-out test set (20% unseen data)</b> to measure genuine predictive capability.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    if not metrics:
        st.error("⚠️ Metrics file not found! Please run `python train_model.py` first.")
        st.stop()

    # Metrics Row
    m_col1, m_col2, m_col3, m_col4 = st.columns(4)

    test_r2 = metrics.get("test_r2", 0.0)
    train_r2 = metrics.get("train_r2", 0.0)
    mae = metrics.get("mae", 0.0)
    rmse = metrics.get("rmse", 0.0)

    with m_col1:
        st.markdown(
            f"""
            <div class="metric-container" style="border-color: rgba(139, 92, 246, 0.4);">
                <div class="metric-label">R² Score (Test Accuracy)</div>
                <div class="metric-value" style="color: #c084fc;">{test_r2:.4f} <span style="font-size: 1rem;">({test_r2*100:.1f}%)</span></div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with m_col2:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Mean Absolute Error (MAE)</div>
                <div class="metric-value" style="color: #38bdf8;">{format_inr_short(mae)}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with m_col3:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Root Mean Sq. Error (RMSE)</div>
                <div class="metric-value" style="color: #60a5fa;">{format_inr_short(rmse)}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with m_col4:
        st.markdown(
            f"""
            <div class="metric-container">
                <div class="metric-label">Train vs Test Generalization</div>
                <div class="metric-value" style="font-size: 1.35rem; color: #6ee7b7;">
                    {train_r2*100:.1f}% vs {test_r2*100:.1f}%
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Actual vs Predicted Visualization
    st.markdown("### 🎯 Actual vs Predicted Prices (Held-Out Test Set)")
    
    test_samples = metrics.get("test_evaluation_sample", [])
    if test_samples:
        test_df = pd.DataFrame(test_samples)

        plt.rcParams.update({
            "figure.facecolor": "#0b0f19",
            "axes.facecolor": "#111827",
            "axes.edgecolor": "#334155",
            "axes.labelcolor": "#e2e8f0",
            "xtick.color": "#94a3b8",
            "ytick.color": "#94a3b8",
            "grid.color": "#1e293b",
            "grid.linestyle": "--",
            "grid.alpha": 0.6,
            "text.color": "#f8fafc"
        })

        chart_m1, chart_m2 = st.columns(2)

        with chart_m1:
            fig_act, ax_act = plt.subplots(figsize=(7, 4.5))
            act_cr = test_df["actual"] / 10000000
            pred_cr = test_df["predicted"] / 10000000

            ax_act.scatter(act_cr, pred_cr, color="#8b5cf6", alpha=0.65, s=35, edgecolors="#c084fc", linewidths=0.5, label="Test Samples")
            
            # Perfect 45-degree reference line
            min_pt = min(act_cr.min(), pred_cr.min())
            max_pt = max(act_cr.max(), pred_cr.max())
            ax_act.plot([min_pt, max_pt], [min_pt, max_pt], color="#38bdf8", linestyle="--", linewidth=2, label="Ideal Line (y = x)")

            ax_act.set_xlabel("Actual Price (₹ in Crores)", fontsize=10, fontweight="bold")
            ax_act.set_ylabel("Predicted Price (₹ in Crores)", fontsize=10, fontweight="bold")
            ax_act.grid(True)
            ax_act.legend(facecolor="#1e293b", edgecolor="#334155")
            st.pyplot(fig_act)
            plt.close(fig_act)

        with chart_m2:
            fig_res, ax_res = plt.subplots(figsize=(7, 4.5))
            residuals_lakhs = test_df["residual"] / 100000

            ax_res.hist(residuals_lakhs, bins=20, color="#6366f1", edgecolor="#1e1b4b", alpha=0.85)
            ax_res.axvline(0, color="#f59e0b", linestyle="--", linewidth=2, label="Zero Error Line")

            ax_res.set_xlabel("Residual Error (Actual - Predicted in ₹ Lakhs)", fontsize=10, fontweight="bold")
            ax_res.set_ylabel("Sample Frequency", fontsize=10, fontweight="bold")
            ax_res.grid(True)
            ax_res.legend(facecolor="#1e293b", edgecolor="#334155")
            st.pyplot(fig_res)
            plt.close(fig_res)

    st.markdown("---")

    # How Linear Regression Works (College Viva Ready Explanation)
    st.markdown("### 🧠 How Multiple Linear Regression Works")
    
    st.markdown(
        r"""
        Multiple Linear Regression models the mathematical relationship between multiple independent predictor features ($X_1, X_2, \dots, X_n$) and a continuous target variable ($y$):
        """
    )
    
    st.latex(r"y = \beta_0 + \beta_1 X_{\text{area}} + \beta_2 X_{\text{bhk}} + \beta_3 X_{\text{baths}} + \beta_4 X_{\text{age}} + \sum \beta_k D_{\text{location}} + \beta_p D_{\text{parking}} + \epsilon")

    st.markdown(
        r"""
        - **$\beta_0$ (Intercept):** The estimated baseline property valuation when all numeric variables are zero and baseline categories apply.
        - **$\beta_i$ (Coefficients / Slopes):** The marginal change in house price in ₹ for every one-unit increase in that respective feature, holding all other features constant.
        - **$\epsilon$ (Residual Error):** The difference between the actual recorded price and the linear prediction. The Ordinary Least Squares (OLS) algorithm minimizes the sum of squared residuals: $\sum (y_i - \hat{y}_i)^2$.
        """
    )

    # Feature Coefficients Table
    st.markdown("#### 🔬 Learned Feature Weights & Coefficients")
    coefs = metrics.get("coefficients", [])
    if coefs:
        coef_df = pd.DataFrame(coefs)
        st.dataframe(
            coef_df,
            use_container_width=True,
            column_config={
                "feature": st.column_config.TextColumn("Feature Name"),
                "coefficient": st.column_config.NumberColumn("Raw Weight (β)", format="%.2f"),
                "formatted_coef": st.column_config.TextColumn("Marginal Effect (₹)")
            }
        )


# =========================================================
# PAGE 5: ABOUT PROJECT
# =========================================================
elif menu_choice == "ℹ️ About Project":
    st.markdown(
        """
        <div class="hero-card" style="padding: 20px 24px;">
            <h2 style="color: #f1f5f9; margin: 0 0 4px 0; font-size: 1.8rem; font-weight: 700;">
                About the AIML Mini Project
            </h2>
            <p style="color: #94a3b8; margin: 0; font-size: 0.95rem;">
                Comprehensive system architecture, technology stack, and machine learning documentation.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Project Information Cards
    p_col1, p_col2 = st.columns(2)

    with p_col1:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-title">📖 Project Overview</div>
                <div class="card-desc">
                    The <b>House Price Prediction System</b> is an academic mini project designed for the Master of Computer Applications (MCA) Artificial Intelligence and Machine Learning (AIML) laboratory curriculum. It provides a complete working implementation of supervised regression applied to real estate valuation.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with p_col2:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-title">⚙️ Core Technology Stack</div>
                <div class="card-desc">
                    • <b>Programming Language:</b> Python 3.13<br>
                    • <b>Algorithm:</b> Multiple Linear Regression (OLS)<br>
                    • <b>ML Framework:</b> Scikit-Learn (Pipeline, ColumnTransformer)<br>
                    • <b>Data Processing:</b> Pandas, NumPy<br>
                    • <b>Visualization:</b> Matplotlib<br>
                    • <b>Frontend:</b> Streamlit (Dark UI)
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # ML Lifecycle Workflow
    st.markdown("### 🔄 Machine Learning Pipeline Architecture")
    st.markdown(
        """
        ```text
        [ 1. Data Ingestion ] ──────> [ 2. Data Cleaning ] ──────> [ 3. Train-Test Split (80/20) ]
        (house_prices.csv)           (Remove nulls/duplicates)      (Prevent Data Leakage)
                                                                             │
                                                                             ▼
        [ 6. Streamlit UI ]  <─────── [ 5. Model Persistence ] <──── [ 4. Scikit-Learn Pipeline ]
        (app.py inference)            (joblib .pkl & metrics)        (ColumnTransformer + OLS)
        ```
        """
    )

    st.markdown("<br>", unsafe_allow_html=True)

    # Limitations & Future Scope
    lim_col1, lim_col2 = st.columns(2)

    with lim_col1:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-title">⚠️ Dataset Limitations</div>
                <div class="card-desc">
                    1. <b>Synthetic Calibration:</b> Modeled using representative rates of Indian metropolitan areas for academic demonstration without live bank/registry records.<br>
                    2. <b>Linearity Assumption:</b> Assumes linear relationship between property dimensions and price, which holds well generally but may soften for ultra-luxury penthouses.<br>
                    3. <b>Macroeconomic Factors:</b> Current model does not incorporate fluctuating home loan interest rates or municipal tax updates.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with lim_col2:
        st.markdown(
            """
            <div class="custom-card">
                <div class="card-title">🚀 Future Scope & Enhancements</div>
                <div class="card-desc">
                    1. <b>Ensemble Models:</b> Implement Random Forest, Gradient Boosting (XGBoost), or LightGBM for non-linear pattern capture.<br>
                    2. <b>Geographic Coordinates:</b> Integrate interactive OpenStreetMap / Folium maps using latitude and longitude markers.<br>
                    3. <b>Amenity Index:</b> Incorporate proximity scores for metro stations, reputed schools, hospitals, and tech parks.<br>
                    4. <b>REST API:</b> Expose FastAPI microservice endpoints for mobile client integration.
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

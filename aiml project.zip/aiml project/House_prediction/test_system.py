"""
test_system.py
--------------
Automated test suite to verify all modules and logic in the House Price Prediction System:
1. Dataset generation and integrity
2. Model training, pipeline consistency, and metrics
3. Helper utilities, Indian Rupee formatting, and input validation
4. Prediction pipeline execution
5. Visualization chart generation
"""

import os
import sys
import unittest
import pandas as pd
import numpy as np

# Safe UTF-8 console output for Windows
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from utils.helpers import (
    load_trained_model,
    load_dataset,
    load_metrics,
    predict_price,
    format_inr,
    format_inr_short,
    format_indian_commas,
    validate_inputs,
    DATA_PATH,
    MODEL_PATH,
    METRICS_PATH
)


class TestHousePricePredictionSystem(unittest.TestCase):

    def test_01_dataset_integrity(self):
        """Test dataset exists, has required columns, >= 1000 records, no missing values."""
        self.assertTrue(os.path.exists(DATA_PATH), f"Dataset missing at {DATA_PATH}")
        df = load_dataset()
        self.assertGreaterEqual(len(df), 1000, "Dataset should have at least 1,000 records.")
        
        expected_cols = ['area_sqft', 'bedrooms', 'bathrooms', 'property_age', 'location', 'parking', 'price']
        for col in expected_cols:
            self.assertIn(col, df.columns, f"Missing required column: {col}")
            
        self.assertEqual(df.isnull().sum().sum(), 0, "Dataset contains missing values.")
        self.assertTrue((df['price'] > 0).all(), "Prices must all be positive.")
        self.assertTrue((df['area_sqft'] >= 300).all(), "Area must be realistic (>= 300 sq.ft).")

    def test_02_model_and_metrics(self):
        """Test that saved model pipeline and metrics JSON are valid."""
        self.assertTrue(os.path.exists(MODEL_PATH), f"Model file missing at {MODEL_PATH}")
        self.assertTrue(os.path.exists(METRICS_PATH), f"Metrics JSON missing at {METRICS_PATH}")
        
        model = load_trained_model()
        self.assertIsNotNone(model)
        self.assertTrue(hasattr(model, "predict"), "Model must have a predict method.")
        
        metrics = load_metrics()
        self.assertIn("test_r2", metrics)
        self.assertIn("mae", metrics)
        self.assertIn("rmse", metrics)
        self.assertGreater(metrics["test_r2"], 0.80, "Model R^2 score should be strong (> 0.80).")

    def test_03_indian_currency_formatting(self):
        """Test Indian numbering system commas and Lakh/Crore formatting."""
        # 1 Lakh = 1,00,000
        commas_1l = format_indian_commas(100000)
        self.assertEqual(commas_1l, "1,00,000")
        
        # 1.25 Crore = 1,25,00,000
        commas_1cr = format_indian_commas(12500000)
        self.assertEqual(commas_1cr, "1,25,00,000")
        
        # Short format
        short_cr = format_inr_short(15000000)
        self.assertEqual(short_cr, "₹ 1.50 Cr")
        
        short_lakh = format_inr_short(7500000)
        self.assertEqual(short_lakh, "₹ 75.00 L")

    def test_04_input_validation(self):
        """Test input validator for valid and invalid house specifications."""
        allowed_locations = ["Whitefield, Bengaluru", "Andheri West, Mumbai"]
        
        # Valid input
        is_valid, msg = validate_inputs(
            area_sqft=1500, bedrooms=3, bathrooms=2, property_age=5,
            location="Whitefield, Bengaluru", parking="Yes",
            allowed_locations=allowed_locations
        )
        self.assertTrue(is_valid)
        self.assertEqual(msg, "")
        
        # Invalid: Area too small
        is_valid, msg = validate_inputs(
            area_sqft=100, bedrooms=1, bathrooms=1, property_age=2,
            location="Whitefield, Bengaluru", parking="Yes"
        )
        self.assertFalse(is_valid)
        
        # Invalid: Unrealistically small area for BHK (e.g. 5 bedrooms in 400 sq.ft)
        is_valid, msg = validate_inputs(
            area_sqft=400, bedrooms=5, bathrooms=2, property_age=2,
            location="Whitefield, Bengaluru", parking="Yes"
        )
        self.assertFalse(is_valid)
        
        # Invalid: Unknown location
        is_valid, msg = validate_inputs(
            area_sqft=1500, bedrooms=3, bathrooms=2, property_age=2,
            location="Unknown Locality", parking="Yes",
            allowed_locations=allowed_locations
        )
        self.assertFalse(is_valid)

    def test_05_prediction_pipeline(self):
        """Test end-to-end prediction execution with the trained model."""
        model = load_trained_model()
        test_payload = {
            "area_sqft": 1600,
            "bedrooms": 3,
            "bathrooms": 2,
            "property_age": 4,
            "location": "Whitefield, Bengaluru",
            "parking": "Yes"
        }
        res = predict_price(model, test_payload)
        
        self.assertIn("raw_price", res)
        self.assertIn("formatted_full", res)
        self.assertIn("formatted_short", res)
        self.assertIn("lower_bound", res)
        self.assertIn("upper_bound", res)
        self.assertGreater(res["raw_price"], 2000000, "Predicted price should be realistic.")
        self.assertLess(res["lower_bound"], res["raw_price"])
        self.assertGreater(res["upper_bound"], res["raw_price"])


if __name__ == "__main__":
    unittest.main()

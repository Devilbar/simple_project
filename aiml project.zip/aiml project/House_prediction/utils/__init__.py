"""
Utility functions and helper modules for House Price Prediction System.
"""

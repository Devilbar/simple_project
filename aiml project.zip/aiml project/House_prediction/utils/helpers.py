"""
utils/helpers.py
----------------
Helper functions for data formatting, validation, model loading, and predictions.
Designed for clarity, robustness, and college viva demonstration.
"""

import os
import json
import joblib
import pandas as pd
import numpy as np

# Base project paths (avoid hardcoded absolute paths)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "house_prices.csv")
MODEL_PATH = os.path.join(BASE_DIR, "models", "house_price_model.pkl")
METRICS_PATH = os.path.join(BASE_DIR, "models", "metrics.json")


def format_indian_commas(amount: float) -> str:
    """
    Format an integer or float with standard Indian numbering commas.
    Example: 12500000 -> "1,25,00,000"
    """
    amount_int = int(round(amount))
    is_negative = amount_int < 0
    s = str(abs(amount_int))
    
    if len(s) <= 3:
        formatted = s
    else:
        last_three = s[-3:]
        remaining = s[:-3]
        parts = []
        while len(remaining) > 2:
            parts.insert(0, remaining[-2:])
            remaining = remaining[:-2]
        if remaining:
            parts.insert(0, remaining)
        parts.append(last_three)
        formatted = ",".join(parts)
        
    return f"-{formatted}" if is_negative else formatted


def format_inr(amount: float, include_words: bool = True) -> str:
    """
    Format a price in Indian Rupees with full commas and Lakh/Crore designation.
    Example: 15400000 -> "₹ 1,54,00,000 (₹ 1.54 Crore)"
    """
    commas_str = format_indian_commas(amount)
    
    if not include_words:
        return f"₹ {commas_str}"
        
    abs_amt = abs(amount)
    if abs_amt >= 10000000:
        crores = abs_amt / 10000000
        words_str = f"₹ {crores:.2f} Crore"
    elif abs_amt >= 100000:
        lakhs = abs_amt / 100000
        words_str = f"₹ {lakhs:.2f} Lakh"
    else:
        words_str = f"₹ {abs_amt:,.0f}"
        
    return f"₹ {commas_str} ({words_str})"


def format_inr_short(amount: float) -> str:
    """
    Format a price compactly in Lakhs or Crores.
    Example: 15400000 -> "₹ 1.54 Cr"
    """
    abs_amt = abs(amount)
    if abs_amt >= 10000000:
        return f"₹ {abs_amt / 10000000:.2f} Cr"
    elif abs_amt >= 100000:
        return f"₹ {abs_amt / 100000:.2f} L"
    else:
        return f"₹ {abs_amt:,.0f}"


def validate_inputs(
    area_sqft: float,
    bedrooms: int,
    bathrooms: int,
    property_age: int,
    location: str,
    parking: str,
    allowed_locations: list = None
) -> tuple[bool, str]:
    """
    Validate user inputs before passing to the ML model.
    Returns (is_valid, error_message).
    """
    # 1. Area validation
    if area_sqft is None or area_sqft < 300 or area_sqft > 10000:
        return False, "Property area must be between 300 and 10,000 sq.ft."
        
    # 2. Bedrooms validation
    if bedrooms is None or bedrooms < 1 or bedrooms > 10:
        return False, "Number of bedrooms must be between 1 and 10."
        
    # 3. Bathrooms validation
    if bathrooms is None or bathrooms < 1 or bathrooms > 10:
        return False, "Number of bathrooms must be between 1 and 10."
        
    # 4. Property age validation
    if property_age is None or property_age < 0 or property_age > 60:
        return False, "Property age must be between 0 (new) and 60 years."
        
    # 5. Logical consistency: reasonable area per bedroom
    if area_sqft / bedrooms < 120:
        return False, f"Area ({area_sqft} sq.ft) is unrealistically small for {bedrooms} bedroom(s). Minimum ~120 sq.ft per bedroom is expected."
        
    # 6. Logical consistency: bathrooms vs bedrooms
    if bathrooms > bedrooms + 2:
        return False, f"Having {bathrooms} bathrooms for {bedrooms} bedroom(s) is unusually high. Please verify your inputs."
        
    # 7. Parking choice
    if parking not in ["Yes", "No"]:
        return False, "Parking selection must be either 'Yes' or 'No'."
        
    # 8. Location check
    if allowed_locations and location not in allowed_locations:
        return False, f"Location '{location}' is not recognized in the trained locations."
        
    return True, ""


def load_dataset(path: str = DATA_PATH) -> pd.DataFrame:
    """
    Safely load housing dataset from CSV.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at: {path}. "
            "Please run 'python generate_dataset.py' first."
        )
    return pd.read_csv(path)


def load_trained_model(path: str = MODEL_PATH):
    """
    Safely load trained scikit-learn Pipeline from pkl file.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Trained model not found at: {path}. "
            "Please run 'python train_model.py' first to train and save the model."
        )
    return joblib.load(path)


def load_metrics(path: str = METRICS_PATH) -> dict:
    """
    Load saved evaluation metrics from JSON file.
    """
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def predict_price(model, input_dict: dict) -> dict:
    """
    Predict house price using the loaded ML model pipeline.
    
    Parameters:
        model: Trained scikit-learn Pipeline.
        input_dict (dict): Dictionary with keys:
            ['area_sqft', 'bedrooms', 'bathrooms', 'property_age', 'location', 'parking']
            
    Returns:
        dict: Prediction details including raw price, formatted price, and estimated range.
    """
    # Create single-row DataFrame matching training feature columns
    input_df = pd.DataFrame([input_dict])
    
    # Generate prediction from pipeline
    pred_raw = float(model.predict(input_df)[0])
    
    # Enforce realistic lower floor
    pred_price = max(1000000.0, round(pred_raw, -3))
    
    # Estimated realistic market range (+- 4%)
    lower_bound = round(pred_price * 0.96, -3)
    upper_bound = round(pred_price * 1.04, -3)
    
    return {
        "raw_price": pred_price,
        "formatted_full": format_inr(pred_price),
        "formatted_short": format_inr_short(pred_price),
        "lower_bound_formatted": format_inr_short(lower_bound),
        "upper_bound_formatted": format_inr_short(upper_bound),
        "lower_bound": lower_bound,
        "upper_bound": upper_bound,
        "input_features": input_dict
    }

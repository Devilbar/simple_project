"""
train_model.py
--------------
Trains a Multiple Linear Regression model with scikit-learn Pipeline and ColumnTransformer.
Steps:
1. Load dataset (data/house_prices.csv)
2. Inspect data types and structure
3. Handle missing values and drop duplicates
4. Split data into 80% train and 20% test (random_state=42)
5. Build preprocessing pipeline (preventing data leakage)
6. Train Linear Regression model on training data
7. Evaluate model on held-out test data (R², MAE, RMSE)
8. Save trained pipeline to models/house_price_model.pkl
9. Save evaluation results and test predictions to models/metrics.json
"""

import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

# Configure UTF-8 encoding for Windows console to handle Rupee and mathematical symbols
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "house_prices.csv")
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "house_price_model.pkl")
METRICS_PATH = os.path.join(MODEL_DIR, "metrics.json")


def train():
    print("=" * 65)
    print("      HOUSE PRICE PREDICTION - MODEL TRAINING PIPELINE")
    print("=" * 65)
    
    # 1. Check & Load Dataset
    if not os.path.exists(DATA_PATH):
        print(f"[!] Dataset not found at {DATA_PATH}.")
        print("[*] Automatically generating synthetic dataset first...")
        from generate_dataset import main as gen_data
        gen_data()
        
    print(f"\n[1/7] Loading dataset from: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    print(f"      Initial shape: {df.shape[0]} rows, {df.shape[1]} columns")
    
    # 2. Inspect data & Clean
    print("\n[2/7] Inspecting data and handling missing/duplicate records...")
    initial_count = len(df)
    
    # Check duplicates
    duplicates = df.duplicated().sum()
    if duplicates > 0:
        df = df.drop_duplicates()
        print(f"      Removed {duplicates} duplicate records.")
    else:
        print("      No duplicate records found.")
        
    # Check missing values
    missing = df.isnull().sum().to_dict()
    has_missing = any(v > 0 for v in missing.values())
    if has_missing:
        print("      Missing values detected; imputing missing records...")
        # Impute numeric with median, categorical with mode
        for col in df.select_dtypes(include=[np.number]).columns:
            df[col] = df[col].fillna(df[col].median())
        for col in df.select_dtypes(exclude=[np.number]).columns:
            df[col] = df[col].fillna(df[col].mode()[0])
    else:
        print("      No missing values found in any column.")
        
    # 3. Separate Features and Target
    print("\n[3/7] Separating independent features (X) and target variable (y)...")
    feature_cols = ['area_sqft', 'bedrooms', 'bathrooms', 'property_age', 'location', 'parking']
    target_col = 'price'
    
    X = df[feature_cols]
    y = df[target_col]
    
    # 4. Train-Test Split (80% Train, 20% Test)
    # Using fixed random_state to ensure reproducible evaluation
    print("\n[4/7] Splitting data into 80% Training and 20% Testing subsets...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    print(f"      Training samples: {len(X_train)} (80%)")
    print(f"      Testing samples:  {len(X_test)} (20%)")
    
    # 5. Define Preprocessing Pipeline
    # Using ColumnTransformer to apply OneHotEncoder to categorical features
    # Numeric features are passed through so coefficients remain directly interpretable
    print("\n[5/7] Building scikit-learn Pipeline with ColumnTransformer...")
    numeric_features = ['area_sqft', 'bedrooms', 'bathrooms', 'property_age']
    categorical_features = ['location', 'parking']
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', 'passthrough', numeric_features),
            ('cat', OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore'), categorical_features)
        ]
    )
    
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', LinearRegression())
    ])
    
    # 6. Fit Pipeline ONLY on Training Data (Prevent Data Leakage)
    print("\n[6/7] Training Multiple Linear Regression model...")
    model_pipeline.fit(X_train, y_train)
    print("      Model training complete!")
    
    # 7. Evaluate on Held-out Test Data
    print("\n[7/7] Evaluating model performance on held-out test data...")
    y_test_pred = model_pipeline.predict(X_test)
    y_train_pred = model_pipeline.predict(X_train)
    
    test_r2 = float(r2_score(y_test, y_test_pred))
    train_r2 = float(r2_score(y_train, y_train_pred))
    mae = float(mean_absolute_error(y_test, y_test_pred))
    mse = float(mean_squared_error(y_test, y_test_pred))
    rmse = float(np.sqrt(mse))
    
    # Display Metrics (Using INR for broad terminal compatibility)
    print("-" * 50)
    print(f"  Test R^2 Score (Accuracy):   {test_r2:.4f} ({test_r2*100:.2f}%)")
    print(f"  Train R^2 Score:            {train_r2:.4f} ({train_r2*100:.2f}%)")
    print(f"  Mean Absolute Error (MAE):  INR {mae:,.2f}")
    print(f"  Root Mean Sq. Error (RMSE): INR {rmse:,.2f}")
    print("-" * 50)
    
    # Extract Feature Names & Coefficients for Interpretability
    regressor = model_pipeline.named_steps['regressor']
    fitted_preprocessor = model_pipeline.named_steps['preprocessor']
    
    # Get feature names after one-hot encoding
    cat_encoder = fitted_preprocessor.named_transformers_['cat']
    cat_feature_names = list(cat_encoder.get_feature_names_out(categorical_features))
    all_feature_names = numeric_features + cat_feature_names
    coefficients = regressor.coef_
    intercept = float(regressor.intercept_)
    
    coef_list = []
    for name, coef in zip(all_feature_names, coefficients):
        coef_list.append({
            "feature": name,
            "coefficient": float(coef),
            "formatted_coef": f"₹ {coef:+,.2f}"
        })
        
    # Save a representative test evaluation sample (for charts on Page 4)
    test_sample_records = []
    test_indices = X_test.index.tolist()
    for i, idx in enumerate(test_indices[:150]):  # First 150 test samples for crisp visualization
        actual_val = float(y_test.iloc[i])
        pred_val = float(y_test_pred[i])
        test_sample_records.append({
            "actual": actual_val,
            "predicted": pred_val,
            "residual": actual_val - pred_val,
            "area_sqft": int(X_test.iloc[i]['area_sqft']),
            "location": str(X_test.iloc[i]['location']),
            "bedrooms": int(X_test.iloc[i]['bedrooms'])
        })
        
    # Prepare metrics dictionary
    metrics_payload = {
        "test_r2": round(test_r2, 4),
        "train_r2": round(train_r2, 4),
        "mae": round(mae, 2),
        "rmse": round(rmse, 2),
        "intercept": round(intercept, 2),
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "total_samples": len(df),
        "coefficients": coef_list,
        "test_evaluation_sample": test_sample_records,
        "locations": sorted(df['location'].unique().tolist())
    }
    
    # Ensure models directory exists
    os.makedirs(MODEL_DIR, exist_ok=True)
    
    # Save pipeline using joblib
    joblib.dump(model_pipeline, MODEL_PATH)
    print(f"\n[+] Trained pipeline saved to: {MODEL_PATH}")
    
    # Save metrics JSON
    with open(METRICS_PATH, "w", encoding="utf-8") as f:
        json.dump(metrics_payload, f, indent=4)
    print(f"[+] Model metrics saved to:    {METRICS_PATH}")
    print("=" * 65)
    print("  TRAINING & PIPELINE PERSISTENCE COMPLETED SUCCESSFULLY")
    print("=" * 65)
    return test_r2, mae, rmse

if __name__ == "__main__":
    train()

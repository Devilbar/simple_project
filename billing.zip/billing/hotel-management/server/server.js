const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const pool = require("./db");

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 5000);

const BASE_ROOM_CHARGE = 1200;
const AC_EXTRA_CHARGE = 300;

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.get("/api/bookings", async (_req, res) => {
  try {
    const [rows] = await pool.execute(
      `
        SELECT
          id,
          customer_name AS customerName,
          id_card AS idCard,
          phone_no AS phoneNo,
          room_no AS roomNo,
          is_ac AS isAc,
          payment,
          created_at AS createdAt
        FROM bookings
        ORDER BY id ASC
      `
    );

    return res.json({ bookings: rows });
  } catch (error) {
    console.error("Fetch bookings failed:", error);
    return res.status(500).json({
      message: `Failed to fetch bookings. MySQL error: ${error.code || "UNKNOWN"}`,
    });
  }
});

app.post("/api/bookings", async (req, res) => {
  const { customerName, idCard, phoneNo, roomNo, isAc } = req.body;

  if (!customerName || !idCard || !phoneNo || !roomNo) {
    return res.status(400).json({ message: "All fields are required." });
  }

  const totalPayment = isAc
    ? BASE_ROOM_CHARGE + AC_EXTRA_CHARGE
    : BASE_ROOM_CHARGE;

  try {
    const insertQuery = `
      INSERT INTO bookings (customer_name, id_card, phone_no, room_no, is_ac, payment)
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    const [result] = await pool.execute(insertQuery, [
      customerName,
      idCard,
      phoneNo,
      roomNo,
      Boolean(isAc),
      totalPayment,
    ]);

    return res.status(201).json({
      message: "Booking saved successfully.",
      bookingId: result.insertId,
      payment: totalPayment,
    });
  } catch (error) {
    if (error && error.code === "ER_DUP_ENTRY") {
      return res
        .status(409)
        .json({ message: "Room number already booked. Choose another room." });
    }

    if (error && error.code === "ER_ACCESS_DENIED_ERROR") {
      return res.status(500).json({
        message: "MySQL login failed. Check DB_USER and DB_PASSWORD in .env.",
      });
    }

    if (error && error.code === "ER_BAD_DB_ERROR") {
      return res.status(500).json({
        message:
          "Database not found. Create it first by running schema.sql in MySQL.",
      });
    }

    if (error && error.code === "ER_NO_SUCH_TABLE") {
      return res.status(500).json({
        message:
          "Table 'bookings' not found. Run schema.sql to create required table.",
      });
    }

    if (error && error.code === "ECONNREFUSED") {
      return res.status(500).json({
        message: "MySQL server is not running on configured host/port.",
      });
    }

    console.error("Booking insert failed:", error);
    return res.status(500).json({
      message: `Failed to save booking. MySQL error: ${error.code || "UNKNOWN"}`,
    });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.listen(PORT, () => {
  console.log(`Hotel management app running at http://localhost:${PORT}`);
});

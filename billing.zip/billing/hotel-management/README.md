# Hotel Management

Simple hotel management project using HTML, CSS, JavaScript, Node.js, and MySQL.

## Features

- Save customer details: name, ID card, phone number, room number
- Payment logic:
  - Non-AC room: Rs 1200
  - AC room: Rs 1500 (Rs 1200 + Rs 300 extra)
- Stores bookings in MySQL table

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create database and table:

   - Open MySQL and run `schema.sql`.

3. Create environment file:

   - Copy `.env.example` to `.env`
   - Fill your MySQL credentials

4. Start app:

   ```bash
   npm start
   ```

5. Open in browser:

   - `http://localhost:5000`

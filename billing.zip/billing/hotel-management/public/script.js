const BASE_CHARGE = 1200;
const AC_EXTRA = 300;

const bookingForm = document.getElementById("bookingForm");
const isAcInput = document.getElementById("isAc");
const paymentAmount = document.getElementById("paymentAmount");
const statusMessage = document.getElementById("statusMessage");

function calculatePayment() {
  return isAcInput.checked ? BASE_CHARGE + AC_EXTRA : BASE_CHARGE;
}

function updatePaymentDisplay() {
  paymentAmount.textContent = `Rs ${calculatePayment()}`;
}

function setStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = type;
}

isAcInput.addEventListener("change", updatePaymentDisplay);

bookingForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  setStatus("Saving booking...", "");

  const formData = new FormData(bookingForm);

  const payload = {
    customerName: formData.get("customerName").trim(),
    idCard: formData.get("idCard").trim(),
    phoneNo: formData.get("phoneNo").trim(),
    roomNo: Number(formData.get("roomNo")),
    isAc: isAcInput.checked,
  };

  try {
    const response = await fetch("/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Something went wrong.");
    }

    setStatus(
      `Booking saved. ID: ${result.bookingId}, Payment: Rs ${result.payment}`,
      "success"
    );
    bookingForm.reset();
    updatePaymentDisplay();
  } catch (error) {
    setStatus(error.message, "error");
  }
});

updatePaymentDisplay();

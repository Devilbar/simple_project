const tableBody = document.querySelector("#bookingsTable tbody");
const statusMessage = document.getElementById("statusMessage");
const refreshBtn = document.getElementById("refreshBtn");

function setStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = type;
}

function formatDate(value) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString();
}

function renderRows(bookings) {
  tableBody.innerHTML = "";

  if (!bookings.length) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 8;
    td.textContent = "No bookings found.";
    td.style.textAlign = "center";
    tr.appendChild(td);
    tableBody.appendChild(tr);
    return;
  }

  for (const b of bookings) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${b.id}</td>
      <td>${b.customerName}</td>
      <td>${b.idCard}</td>
      <td>${b.phoneNo}</td>
      <td>${b.roomNo}</td>
      <td>${b.isAc ? "Yes" : "No"}</td>
      <td>Rs ${Number(b.payment).toFixed(0)}</td>
      <td>${formatDate(b.createdAt)}</td>
    `;
    tableBody.appendChild(tr);
  }
}

async function loadBookings() {
  setStatus("Loading bookings...", "");

  try {
    const response = await fetch("/api/bookings");
    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Failed to load bookings.");
    }

    renderRows(result.bookings || []);
    setStatus(`Loaded ${result.bookings?.length || 0} bookings.`, "success");
  } catch (error) {
    setStatus(error.message, "error");
  }
}

refreshBtn.addEventListener("click", loadBookings);
loadBookings();
